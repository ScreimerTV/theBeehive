class Comment {
    constructor(id, body, email, name, postId) {
        this.id = id;
        this.body = body;
        this.email = email;
        this.name = name;
        this.postId = postId;
    }
}