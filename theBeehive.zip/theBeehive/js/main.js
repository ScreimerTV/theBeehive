/**
* @name main.js
* @file Add a small description for this file.
* @author David Gutiérrez, wwwdcalderon@gmail.com
* @version 1.0.0
*/

"use strict";

window.addEventListener('load', init, false);

function init() {
    var appManager = new AppManager();
}