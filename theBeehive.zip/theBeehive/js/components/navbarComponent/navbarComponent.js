class NavBarComponent extends Component {
    constructor(appManager, parent) {
        super(appManager, parent);
        this.parent.removeChild(this.container);
        this.container = document.createElement('nav');
        this.container.classList.add('navbarComponent');
        this.parent.appendChild(this.container);
    }
}