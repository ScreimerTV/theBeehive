class MainComponent extends Component {
    constructor(appManager, parent) {
        super(appManager, parent);
        this.container.classList.add('mainComponent');
        this.navbarComponent = new NavBarComponent(this.appManager, this.container);
        this.userListComponent = new UserListComponent(this.appManager, this.container);
    }
}